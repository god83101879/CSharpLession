﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace BasicWebForm
{
    public class Sharp
    {
        /*
        public double GetArea()
        {
            return 0;
        }

        public class Circle : Sharp
        {
            public Circle() { }

            public Circle(double raduis)
            {
                this.Raduis = raduis;
            }
            double result = Math.Pow(Raduis, 2) * Math.PI;
            return result;
        }

        public class Main
        {
            Circle circle = new Circle();
            circle.Raduis = 3;

            Console.WRiteLine(circle.GetArea());
        }*/
    }

}